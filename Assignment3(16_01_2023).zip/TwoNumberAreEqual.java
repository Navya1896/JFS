//Write a program to check if the two numbers 23 and 45 are equal.
public class TwoNumberAreEqual {
    public static void main(String[] args){
        int a = 23, b= 45;
        if(a == b){
            System.out.println("The two numbers are equal");
        }
        else {
            System.out.println("The two numbers are not equal");
        }
    }
}
