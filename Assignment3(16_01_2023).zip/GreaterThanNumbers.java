//Assign values of variables 'a' and 'b' as 55 and 70 respectively and
// then check if both the conditions 'a < 50' and 'a < b' are true.
public class GreaterThanNumbers {
    public static void main(String[] args) {
        int a = 55, b = 70;
        if (a < 50 && a < b){
            System.out.println("The Conditions 'a<50' and 'a<b' are True");
        }
        else{
            System.out.println("The conditions a<50 and a<b are False");
        }
    }

}
